
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapsExample {

    public static void main(String[] args) {
        
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        System.out.println("HashMap Example:");
        printMap(hashMap);
        System.out.println();

       
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Apple", 10);
        treeMap.put("Banana", 5);
        treeMap.put("Orange", 8);

        System.out.println("TreeMap Example (Sorted by keys):");
        printMap(treeMap);
        System.out.println();

 
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Dog", 25);
        linkedHashMap.put("Cat", 15);
        linkedHashMap.put("Fish", 30);

        System.out.println("LinkedHashMap Example (Maintains insertion order):");
        printMap(linkedHashMap);
    }

    
    private static <K, V> void printMap(Map<K, V> map) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}